package com.wiseasy.pds.response;

/**
 * Created by Android Studio.
 * User: pupan
 * Date: 8/17/2022
 * Time: 5:09 PM
 * @author pupan
 */
public class TransactionRefundResponse extends  BaseResponse {
    String trans_no;
    int trans_status;
}
