package com.wiseasy.pds.response;

/**
 * Created by Android Studio.
 * User: pupan
 * Date: 8/16/2022
 * Time: 4:10 PM
 */
public class CScanBPaymentResponse extends BaseResponse {
    String trans_no;
    String qrcode_url;
}
