package com.wiseasy.pds.response;

/**
 * Created by Android Studio.
 * User: pupan
 * Date: 8/17/2022
 * Time: 5:10 PM
 * @author pupan
 */
public class TransactionCancelResponse extends BaseResponse{
}
